//  function exercise(){
//     alert("hello)");
// };

var count = 0;
function myfunction(x){
    var x;
    if(x == 1){
        count = count + 1;
    }

    if(count == 1){
        document.getElementById("change").style.background = "red";
    }
    else if(count == 2){
        document.getElementById("change").style.background = "green";
        count = 0;
    }
}



